import { menuHandler, cartHandler, calorieCounterHandler } from "..";
import {
  getItemId,
  getModifierWithItemId,
  getEnrichedModifiers,
  getEnrichedItems
} from "../utils/cartUtil";

import {
  getMaxCalorie,
  hasOneOfEachRule,
  getMinCalorie
} from "../utils/caloriesUtil";
import cart from "../data/cart.json";                  // If you are seeing a warning here, it is becuase
import chickenPlatter from "../data/4pc-chicken.json"; // ts-jest is used instead of babel-jest, but it works fine.

/**
 * These tests only provide a basic assessment of correctness.
 *
 * Feel free to modify as you find necessary.
 */

describe("Homework", () => {
  const expectedResponseShape = {
    body: expect.any(String),
    statusCode: expect.any(Number)
  };

  describe("Question #1: Menu", () => {
    it("should return the correct data shape", async () => {
      const response = await menuHandler();

      expect(response).toEqual(expectedResponseShape);
    });
  });

  describe("Question #2: Cart", () => {
    it("should return the correct data shape", async () => {
      const response = await cartHandler();

      expect(response).toEqual(expectedResponseShape);
    });
  });

  describe("Question #3: Calorie counter", () => {
    it("should return the correct data shape", async () => {
      const response = await calorieCounterHandler();

      expect(response).toEqual(expectedResponseShape);
    });
  });

  describe("Cart Utility", () => {
    it("should return the itemId for a plunum", () => {
      expect(getItemId(50100)).toBe(99);
    });

    it("should add itemId property to an object", () => {
      const modifierWithItemId: any = {
        itemId: 99,
        plunum: "50100",
        description: "1 BISCUIT",
        quantity: 1
      };

      expect(getModifierWithItemId(cart.order.items[0].modifiers[0])).toEqual(
        modifierWithItemId
      );
    });

    it("should return an enriched modifiers array", () => {
      const enrichedModifiers: Array<any> = [
        {
          itemId: 99,
          plunum: "50100",
          description: "1 BISCUIT",
          quantity: 1
        },
        {
          itemId: 199,
          plunum: "50900",
          description: "REGULAR RED BEANS & RICE",
          quantity: 1
        },
        {
          itemId: 199,
          plunum: "50700",
          description: "REGULAR MAC & CHEESE",
          quantity: 1
        },
        {
          itemId: 229,
          plunum: "80102",
          description: "32OZ COKE",
          quantity: 1
        }
      ];

      expect(getEnrichedModifiers(cart.order.items[0].modifiers)).toEqual(
        enrichedModifiers
      );
    });

    it("should return an enriched items array", () => {
      const enrichedItems: Array<any> = [
        {
          description: "2pc Mild Chicken Platter White",
          itemId: 829,
          plunum: "1010230",
          quantity: 1,
          modifiers: [
            {
              description: "1 BISCUIT",
              itemId: 99,
              plunum: "50100",
              quantity: 1
            },
            {
              plunum: "50900",
              itemId: 199,
              description: "REGULAR RED BEANS & RICE",
              quantity: 1
            },
            {
              plunum: "50700",
              itemId: 199,
              description: "REGULAR MAC & CHEESE",
              quantity: 1
            },
            {
              description: "32OZ COKE",
              itemId: 229,
              plunum: "80102",
              quantity: 1
            }
          ]
        }
      ];

      expect(getEnrichedItems(cart.order.items)).toEqual(enrichedItems);
    });
  });

  describe("Calories Utility", () => {
    it("should return true if the given comboItem contains options that has to be picked atleast once", () => {
      expect(hasOneOfEachRule(chickenPlatter.comboItems[0])).toBe(true);
    });

    it("should return the minimum calorie", () => {
      expect(getMinCalorie()).toBe(1347);
    });
    it("should return the maximum calorie", () => {
      expect(getMaxCalorie()).toBe(2253);
    });
  });
});
