"use strict";

import plus from "../data/plus.json";
import cart from "../data/cart.json";

/**
 * This method returns the `itemId` for a matching `plunum`.
 * 
 * @param plunum
 */
export function getItemId(plunum: number) {
  const RestaurantPosData: any = JSON.parse(plus.data.RestaurantPosData.plus);
  const plukey = `plu_${plunum}`;
  return RestaurantPosData[plukey];
}

/**
 * This method enriches modifers by adding
 * a new key `itemId` and its corresponding value.
 * 
 * @param modifier
 */
export function getModifierWithItemId(modifier: any) {
  let modifierWithItemId: any = {
    itemId: getItemId(modifier.plunum),
    plunum: modifier.plunum,
    description: modifier.description,
    quantity: modifier.quantity
  };
  return modifierWithItemId;
}

/**
 * This method assembles all the enriched `modifers`.
 * 
 * @param modifiers 
 */
export function getEnrichedModifiers(modifiers: Array<any>) {
  let enrichedModifiers: Array<any> = [];

  modifiers.forEach(function(modifier) {
    enrichedModifiers.push(getModifierWithItemId(modifier));
  });

  return enrichedModifiers;
}

/**
 * This method enriches the `item(s)` with its `itemId`
 * and with its enriched `modifiers`.
 * 
 * @param items
 */
export function getEnrichedItems(items: Array<any>) {
  let enrichedItemsArray: Array<any> = [];
  items.forEach(function(item) {
    enrichedItemsArray.push({
      itemId: getItemId(item.plunum),
      plunum: item.plunum,
      description: item.description,
      quantity: item.quantity,
      modifiers: getEnrichedModifiers(item.modifiers)
    });
  });
  return enrichedItemsArray;
}

/**
 * This method returns enriched `items` and enriched `modifers` within.
 */
export function enrichedCart() {
  let enriched: any = cart;
  enriched.order.items = getEnrichedItems(cart.order.items);
  return enriched;
}
