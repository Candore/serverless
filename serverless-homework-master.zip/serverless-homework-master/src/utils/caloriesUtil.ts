"use strict";

import chickenPlatter from "../data/4pc-chicken.json";

/**
 * This method checks for a given `comboItem` and its `comboItemoptions`,
 * if it requires to select each of the option atleast once.
 *
 * @param comboItem
 */
export function hasOneOfEachRule(comboItem: any) {
  let count = 0;
  comboItem.comboItemOptions.forEach(element => {
    if (element.minAmount == 1 && element.maxAmount == 1) {
      count++;
    }
  });

  return comboItem.amountRequiredToSelect === count;
}

/**
 * This helper method loops through `comboItemOptions` of 
 * a given combo item and adds their calories if the `amountRequiredToSelect` is greater than 1. 
 * 
 * Else if the `amountRequiredToSelect` is only one, 
 * then it simply adds the calory of that one item to the total.
 * 
 * @param comboItem 
 * 
 */
function getTotalForHasOneOfEachItem(comboItem:any) {
  let total: number = 0;
 
    if (comboItem.amountRequiredToSelect > 1) {
      total += comboItem.comboItemOptions.reduce(function(a: any, b: any) {
        if (typeof a === "number") {
          return a + b.option.nutrition.calories;
        } else {
          return a.option.nutrition.calories + b.option.nutrition.calories;
        }
      });
    } else {
      total += comboItem.comboItemOptions[0].option.nutrition.calories;
    }
  
  return total;
}
/**
 * Rules to calculate max calories
 *
 * 1.If a combo item has options that has to be picked atleast once
 *  then check if the number of options available is the same as the `amountRequiredToSelect`.
 *  If so, then add the calories of each of the options once.
 *
 * 2.If there is only one option available for a combo item that requires only one selection,
 * then add that option's calorie to total.
 *
 * 3.If options available for a combo item is more than the `amountRequiredToSelect`,
 * then check which option has max calories, and keep adding the same item's
 * calory as long it is reusuable `(maxAmount >= amountRequired)`
 */
export function getMaxCalorie() {
  var total: number = 0;
  for (let index = 0; index < chickenPlatter.comboItems.length; index++) {
    let comboItem: any = chickenPlatter.comboItems[index];
    if (hasOneOfEachRule(comboItem)) {
      total += getTotalForHasOneOfEachItem(comboItem);
    } else {
      for (let x = 0; x < comboItem.amountRequiredToSelect; x++) {
        total += Math.max.apply(
          Math,
          comboItem.comboItemOptions.map(function(option) {
            if (option.maxAmount >= comboItem.amountRequiredToSelect)
              return option.option.nutrition.calories;
          })
        );
      }
    }
  }
  return total;
}

/**
 * Rules to calculate min calories
 *
 * 1.If a combo item has options that has to be picked atleast once
 *  then check if the number of options available is the same as the `amountRequiredToSelect`.
 *  If so, then add the calories of each of the options once.
 *
 * 2.If there is only one option available for a combo item that requires only one selection,
 * then add that option's calorie to total.
 *
 * 3.If options available for a combo item is more than the `amountRequiredToSelect`,
 * then check which option has min calories, and keep adding the same item's
 * calory as long it is reusuable `(maxAmount >= amountRequired)`
 */
export function getMinCalorie() {
  var total: number = 0;
  for (let index = 0; index < chickenPlatter.comboItems.length; index++) {
    let comboItem: any = chickenPlatter.comboItems[index];
    if (hasOneOfEachRule(comboItem)) {
       total += getTotalForHasOneOfEachItem(comboItem);
    } else {
      for (let x = 0; x < comboItem.amountRequiredToSelect; x++) {
        total += Math.min.apply(
          Math,
          comboItem.comboItemOptions.map(function(option) {
            if (option.maxAmount >= comboItem.amountRequiredToSelect)
              return option.option.nutrition.calories;
          })
        );
      }
    }
  }
  return total;
}
